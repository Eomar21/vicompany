﻿namespace Vri.Domain.Models;

public enum TransactionType
{
    Buy,
    Sell
}